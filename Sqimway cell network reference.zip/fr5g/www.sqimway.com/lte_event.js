var ctx;
var timer_event;
var event_val = 'A12';
var whitz = 'Teal';
var t = Math.floor(Math.random()*400);
var dir = false;

window.onload = function()
{
  // LTE Events
  var event = document.getElementById('lte_event_js');
    if(!event) {
      alert("Impossible to retrieve tag id");
      return;
    }

  ctx = event.getContext('2d');
    if(!ctx) {
      alert("Impossible to retreive tag context");
      return;
    }

/* ************************************************ */
function draw_A12() {
  ctx.beginPath();
  // Threshold low
  ctx.moveTo(55, 350);
  ctx.lineTo(450, 350);
  // Threshold high
  ctx.moveTo(55, 150);
  ctx.lineTo(450, 150);

  ctx.strokeStyle = "rgb(255,0,0)";
  ctx.stroke();

  // Color gradient
  var lingrad = ctx.createLinearGradient(100, 450, 150, 150);
  lingrad.addColorStop(0, 'white');
  lingrad.addColorStop(1, whitz);
  ctx.fillStyle = lingrad;

  // Primary cell
  ctx.strokeStyle = "blue";
  ctx.strokeRect(100,450-t,100,t);
  ctx.fillRect(100,450-t,100,t);

  // Cell name
  ctx.fillStyle = "blue";
  ctx.fillText("Serving cell", 105, 470);
  // Threshold
  ctx.fillText("Threshold 1", 350, 345);
  ctx.fillText("Threshold 2", 350, 145);

  if (dir) {
    if ((t > 100) && (t < 250)) {
      ctx.fillText("Event A1 : Serving becomes better than threshold 1", 60, 75);
    }
    if (t > 350) {
      dir = false;
    }
    t++;
  } else {
    if ((t < 300) && (t > 150)) {
      ctx.fillText("Event A2 : Serving becomes worse than threshold 2", 60, 75);
    }
    if (t < 50) {
      dir = true;
    }
    t--;
  }
}

/* ************************************************ */
function draw_A34() {
  ctx.beginPath();
  // Threshold
  ctx.moveTo(55, 150);
  ctx.lineTo(450, 150);

  ctx.strokeStyle = "rgb(255,0,0)";
  ctx.stroke();

  // Color gradient
  var lingrad = ctx.createLinearGradient(100, 450, 150, 150);
  lingrad.addColorStop(0, 'white');
  lingrad.addColorStop(1, whitz);
  ctx.fillStyle = lingrad;

  // Primary cell
  ctx.strokeStyle = "blue";
  ctx.strokeRect(100,250,100,200);
  ctx.fillRect(100,300,100,150);

  // Neighbour cell
  ctx.strokeStyle = "blue";
  ctx.strokeRect(250,450-t,100,t);
  ctx.fillRect(250,450-t,100,t);

  // Cell name
  ctx.fillStyle = "blue";
  ctx.fillText("Serving cell", 105, 470);
  ctx.fillText("Neighbour cell", 255, 470);

  if (dir) {
    if (t > 300) {
      ctx.fillText("Event A4 : Neighbour becomes better than threshold", 60, 145);
    }
    if (t > 200) {
      ctx.fillText("Event A3 : Neighbour becomes offset better than PCell", 60, 245);
    }
    if (t > 350) {
      dir = false;
    }
    t++;
  } else {
    if (t < 100) {
      dir = true;
    }
    t--;
  }
}

/* ************************************************ */
function draw_A5() {
  ctx.beginPath();
  // Threshold low
  ctx.moveTo(55, 300);
  ctx.lineTo(450, 300);
  // Threshold high
  ctx.moveTo(55, 200);
  ctx.lineTo(450, 200);

  ctx.strokeStyle = "rgb(255,0,0)";
  ctx.stroke();

  // Color gradient
  var lingrad = ctx.createLinearGradient(100, 450, 150, 150);
  lingrad.addColorStop(0, 'white');
  lingrad.addColorStop(1, whitz);
  ctx.fillStyle = lingrad;

  // Primary cell
  ctx.strokeStyle = "blue";
  ctx.strokeRect(100,450-t,100,t);
  ctx.fillRect(100,450-t,100,t);

  // Neighbour cell
  ctx.strokeRect(250,t+50,100,400-t);
  ctx.fillRect(250,t+50,100,400-t);

  // Cell name
  ctx.fillStyle = "blue";
  ctx.fillText("Serving cell", 105, 470);
  ctx.fillText("Neighbour cell", 255, 470);

  if (dir) {
    if (t > 300) {
      dir = false;
    }
    t++;
  } else {
    if (t < 150) {
      ctx.fillText("Event A5 : PCell < Threshold 1 and Neighbour > Threshold 2", 60, 75);
    }
    if (t < 100) {
      dir = true;
    }
    t--;
  }
}

/* ************************************************ */
  var draw = function() {
    ctx.fillStyle = "rgb(255,248,220)";
    ctx.fillRect(0, 0, 500, 500);
    ctx.font = "14pt Calibri,Geneva,Arial";
    //ctx.globalAlpha = 0.2;

    ctx.beginPath();
    // Axe X
    ctx.moveTo(40, 450);
    ctx.lineTo(450, 450);
    // Axe Y
    ctx.moveTo(50, 460);
    ctx.lineTo(50, 50);
    for (var i = 2; i < 9; i++) {
      ctx.moveTo(45, 50*i);
      ctx.lineTo(55, 50*i);
    }
    ctx.strokeStyle = "blue";
    ctx.stroke();

    switch(event_val) {
    case "A12":
      draw_A12();
      break;
    case "A34":
      draw_A34();
      break;
    case "A5":
      draw_A5();
      break;
    default:
      clearInterval(timer_event);
      break;
    }
  }

  /* ************************************************ */
  timer_event = setInterval(draw, 30);
}

/* ************************************************ */
function lte_event(radio) {
  //alert("debug lte_event : "+radio.value);
  event_val = radio.value;
}

function lte_color(radio) {
    switch(radio.value) {
    case "C1":
      whitz = 'Teal';
      break;
    case "C2":
      whitz = 'ForestGreen';
      break;
    case "C3":
      whitz = 'MediumVioletRed';
      break;
    }
}