wget --mirror --convert-links --adjust-extension -U Mozilla --page-requisites --no-parent http://sqimway.com/
