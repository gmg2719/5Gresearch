function riv(ndlrbg,input,output) {
  var lvcrb = 0; vrbgstart = 0;
  //console.log("input = %d", input);

  for (var n=1; n<=ndlrbg; n++) {
    for (var m=0; m<=ndlrbg-n; m++) {
      if ((n-1) <= Math.floor(ndlrbg/2)) {
        if (input == ndlrbg*(n-1) + m) {
          lvcrb = n;
          vrbgstart = m;
        }
      } else {
        if (input == ndlrbg*(ndlrbg - n + 1) + ndlrbg - 1 - m) {
          lvcrb = n;
          vrbgstart = m;
        }
      }
    }
  }
  output.start = vrbgstart;
  output.nrbg = lvcrb;
}

// LTE RIV
function lte_riv_rbg(riv_in) {
  var result = {start:0, nrbg:0}; 
  var value;
  //console.log("riv_in = " + riv_in);

  riv_in = riv_in.replace(/\s/g, "");
  var rivOk = /^[0-9]+$/i.test(riv_in);
  if (rivOk) {
    value = parseInt(riv_in,10);
    riv(25, value, result);
  } else {
    result.start = "RIV invalid";
    result.nrbg = "-";
  }
  document.lte_riv.lte_vrbgstart.value = result.start;
  document.lte_riv.lte_lvcrb.value = result.nrbg;
}

function lte_rbg_riv(start,nrbg) {
  var riv;
  var ndlrbg = 25;
  //console.log("start = " + start + ", nrbg = " + nrbg);

  start = start.replace(/\s/g, "");
  var startOk = /^[0-9]+$/i.test(start);
  if (startOk) {
    start = parseInt(start,10);
    if (start < ndlrbg) {
      nrbg = nrbg.replace(/\s/g, "");
      var nrbgOk = /^[0-9]+$/i.test(nrbg);
      if (nrbgOk) {
        nrbg = parseInt(nrbg,10);
        if ((nrbg >= 1) && (nrbg <= (ndlrbg - start))) {
          if ((nrbg - 1) <= Math.floor(ndlrbg/2)) {
            riv = ndlrbg*(nrbg - 1) + start;
          } else {
            riv = ndlrbg*(ndlrbg - nrbg + 1) + ndlrbg - 1 - start;
          }
        } else {
          riv = "#RBG value invalid";
        }
      } else {
        riv = "#RBG invalid";
      }
    } else {
      riv = "RBG start value invalid";
    }
  } else {
    riv = "RBG start invalid";
  }

  document.lte_riv.lte_riv_in.value = riv;
}

function lte_clear_riv() {
  document.getElementsByName('lte_riv_in')[0].placeholder='';
  document.getElementsByName('lte_vrbgstart')[0].placeholder='';
  document.getElementsByName('lte_lvcrb')[0].placeholder='';
  document.lte_riv.lte_riv_in.value = '';
  document.lte_riv.lte_vrbgstart.value = '';
  document.lte_riv.lte_lvcrb.value = '';
}

// NR RIV
function nr_riv_rbs(bwp_size,riv_in) {
  var result = {start:0, nrbg:0}; 
  var value;
  //console.log("bwp_size = %d", bwp_size);

  bwp_size = bwp_size.replace(/\s/g, "");
  var bwpOk = /^[0-9]+$/i.test(bwp_size);
  if (bwpOk) {
    bwp_size = parseInt(bwp_size,10);
    if ((bwp_size > 0) && (bwp_size <= 275)) {
      riv_in = riv_in.replace(/\s/g, "");
      var rivOk = /^[0-9]+$/i.test(riv_in);
      if (rivOk) {
        value = parseInt(riv_in,10);
        riv(bwp_size, value, result);
      } else {
        result.start = "RIV invalid";
        result.nrbg = "-";
      }
    } else {
      result.start = "BWP size invalid";
      result.nrbg = "-";
    }
  } else {
    result.start = "BWP invalid";
    result.nrbg = "-";
  }
  document.nr_riv.nr_vrbstart.value = result.start;
  document.nr_riv.nr_lvcrb.value = result.nrbg;
}

function nr_rbs_riv(bwp_size,start,nrbg) {
  var riv;

  bwp_size = bwp_size.replace(/\s/g, "");
  var bwpOk = /^[0-9]+$/i.test(bwp_size);
  if (bwpOk) {
    bwp_size = parseInt(bwp_size,10);
    if ((bwp_size > 0) && (bwp_size <= 275)) {
      var ndlrbg = bwp_size;

      start = start.replace(/\s/g, "");
      var startOk = /^[0-9]+$/i.test(start);
      if (startOk) {
        start = parseInt(start,10);
        if (start < ndlrbg) {
          nrbg = nrbg.replace(/\s/g, "");
          nrbgOk = /^[0-9]+$/i.test(nrbg);
          if (nrbgOk) {
            nrbg = parseInt(nrbg,10);
            if ((nrbg >= 1) && (nrbg <= (ndlrbg - start))) {
              if ((nrbg - 1) <= Math.floor(ndlrbg/2)) {
                riv = ndlrbg*(nrbg - 1) + start;
              } else {
                riv = ndlrbg*(ndlrbg - nrbg + 1) + ndlrbg - 1 - start;
              }
            } else {
              riv = "#RBs value invalid";
            }
          } else {
            riv = "#RBs invalid";
          }
        } else {
          riv = "RB start value invalid";
        }
      } else {
        riv = "RB start invalid";
      }
    } else {
      riv = "BWP size invalid";
    }
  } else {
    riv = "BWP invalid";
  }
  document.nr_riv.nr_riv_in.value = riv;
}

function nr_clear_riv() {
  document.getElementsByName('nr_riv_in')[0].placeholder='';
  document.getElementsByName('nr_vrbstart')[0].placeholder='';
  document.getElementsByName('nr_lvcrb')[0].placeholder='';
  document.nr_riv.nr_riv_in.value = '';
  document.nr_riv.nr_vrbstart.value = '';
  document.nr_riv.nr_lvcrb.value = '';
}

// NR SLIV
function sliv(input, output) {
  var start = 0; symbols = 0;
  var nSymbols = 14;

  for (var n=1; n<=nSymbols; n++) {
    for (var m=0; m<=nSymbols-n; m++) {

      if ((n-1) <= (nSymbols/2)) {
        if (input == nSymbols*(n-1) + m) {
          symbols = n;
          start = m;
        }
      } else {
        if (input == nSymbols*(nSymbols - n + 1) + nSymbols - 1 - m) {
          symbols = n;
          start = m;
        }
      }
    }
  }
  
  output.start = start;
  output.symbols = symbols;
}

function sliv_sl(sliv_in) {
  var result = {start:0, symbols:0}; 
  var value;

  sliv_in = sliv_in.replace(/\s/g, "");
  var slivOk = /^[0-9]+$/i.test(sliv_in);
  if (slivOk) {
    value = parseInt(sliv_in,10);
    sliv(value, result);
  } else {
    result.start = "SLIV invalid";
    result.symbols = "-";
  }

  document.nr_sliv.slivStart.value = result.start;
  document.nr_sliv.slivSymbols.value = result.symbols;
}

function sl_sliv(start,symbols) {
  var sliv;
  var nSymbols = 14;

  start = start.replace(/\s/g, "");
  var startOk = /^[0-9]+$/i.test(start);
  if (startOk) {
    start = parseInt(start,10);
    if (start < nSymbols) {
      symbols = symbols.replace(/\s/g, "");
      var isOk = /^[0-9]+$/i.test(symbols);
      if (isOk) {
        symbols = parseInt(symbols,10);
        if ((symbols >= 1) && (symbols <= (nSymbols - start))) {
          if ((symbols - 1) <= (nSymbols/2)) {
            sliv = nSymbols*(symbols - 1) + start;
          } else {
            sliv = nSymbols*(nSymbols - symbols + 1) + nSymbols - 1 - start;
          }
        } else {
          sliv = "L value invalid";
        }
      } else {
        sliv = "L invalid";
      }
    } else {
      sliv = "S value invalid";
    }
  } else {
    sliv = "S invalid";
  }

  document.nr_sliv.sliv_in.value = sliv;
}

function clear_sliv() {
  document.getElementsByName('sliv_in')[0].placeholder='';
  document.getElementsByName('slivStart')[0].placeholder='';
  document.getElementsByName('slivSymbols')[0].placeholder='';
  document.nr_sliv.sliv_in.value = '';
  document.nr_sliv.slivStart.value = '';
  document.nr_sliv.slivSymbols.value = '';
}

// PCI
function pci_nid(cell_id) {
  cell_id = cell_id.replace(/\s/g, "");
  var isOk = /^[0-9]+$/i.test(cell_id);
  value = parseInt(cell_id,10);
  if ((isOk) && (cell_id < 1008)) {
    n_id_1 = Math.floor(value/3);
    n_id_2 = value%3;
  } else {
    n_id_1 = "PCI invalid [0 .. 1007]";
    n_id_2 = "-";
  }
  document.calc_pci.n_id_1.value = n_id_1;
  document.calc_pci.n_id_2.value = n_id_2;
}

function nid_pci(n_id_1, n_id_2) {
  n_id_1 = n_id_1.replace(/\s/g, "");
  n_id_2 = n_id_2.replace(/\s/g, "");
  var isOk = /^[0-9]+$/i.test(n_id_1);
  var val1 = parseInt(n_id_1,10);
  if ((isOk) && (val1 < 336)) {
    isOk = /^[0-9]+$/i.test(n_id_2);
    var val2 = parseInt(n_id_2,10);
    if ((isOk) && (val2 < 3)) {
      cell_id = val1*3 + val2;
    } else {
      cell_id = "N_ID(2) invalid";
    }
  } else {
    cell_id = "N_ID(1) invalid";
  }
  document.calc_pci.cell_id.value = cell_id;
}

function clear_pci() {
  document.getElementsByName('cell_id')[0].placeholder='';
  document.getElementsByName('n_id_1')[0].placeholder='';
  document.getElementsByName('n_id_2')[0].placeholder='';
  document.calc_pci.cell_id.value = '';
  document.calc_pci.n_id_1.value = '';
  document.calc_pci.n_id_2.value = '';
}

function nr_bwp_fdra(bwp_size) {
  var fdra;

  bwp_size = bwp_size.replace(/\s/g, "");
  var bwpOk = /^[0-9]+$/i.test(bwp_size);
  if (bwpOk) {
    bwp_size = parseInt(bwp_size,10);
    if ((bwp_size > 0) && (bwp_size <= 275)) {
      var nrbg = bwp_size;
      fdra = Math.ceil(Math.log2(nrbg*(nrbg+1)/2));
    } else {
      riv = "BWP size invalid";
    }
  } else {
    riv = "BWP invalid";
  }

  document.nr_fdra.fdra.value = fdra;
}

function clear_fdra() {
  document.getElementsByName('fdra')[0].placeholder='';
  document.nr_fdra.fdra.value = '';
}

function calc_lb_two(input) {
  var result;
  result = Math.round(Math.log2(input)*100000)/100000;

  document.lb2.exp_two.value = result;
}

function calc_exp_two(input) {
  var result;
  result = Math.round(Math.pow(2, input)*100000)/100000;

  document.lb2.lb_two.value = result;
}

function clear_lb_two() {
  document.lb2.lb_two.value = '';
  document.lb2.exp_two.value = '';
}

function calc_lb_ten(input) {
  var result;
  result = Math.round(Math.log10(input)*100000)/100000;

  document.lb10.exp_ten.value = result;
}

function calc_exp_ten(input) {
  var result;
  result = Math.round(Math.pow(10, input)*100000)/100000;

  document.lb10.lb_ten.value = result;
}

function clear_lb_ten() {
  document.lb10.lb_ten.value = '';
  document.lb10.exp_ten.value = '';
}
