jQuery.fn.extend({
  appendSvg:function (nom, attributs) {
  var svg = document.createElementNS("http://www.w3.org/2000/svg",nom);
  for (var cle in attributs) {
    var valeur = attributs[cle];
    svg.setAttribute(cle,valeur);
  }
  var appendices = this.length;
  for (var i = 0; i < appendices; i++) {
    this[i].appendChild(svg);
  }
  return svg;
  }
});

function SVG(tag) {
  return document.createElementNS('http://www.w3.org/2000/svg', tag);
}

var drawRect = function(x,y,w,h,color) {
  var $svg = $("svg");
  $(SVG('rect'))
      .attr('x', x)
      .attr('y', y)
      .attr('width', w)
      .attr('height', h)
      .attr('fill', color)
      .appendTo($svg);
};